class RegionCollection {
  constructor(items) {
    this.items = items;
  }

  first() {
    return new RegionPath(this.items[0]);
  }

  find(index) {
    return new RegionPath(this.items[index]);
  }

  static get() {
    return new RegionCollection(Array.from(document.querySelectorAll("path")));
  }

  forEach(funct) {
    this.items.forEach(item => {
      funct(new RegionPath(item));
    });
  }

  findByName(nombre) {
    return new RegionPath(document.getElementById(nombre));
  }

  findByRegion(region) {
    return new RegionPath(document.getElementById(region));
  }
}

class RegionPath {
  constructor(elemento) {
    this.element = elemento;
  }

  fill(color) {
    if (this.element) {
      this.element.setAttribute("fill", color);
    } else {
      console.log("El elemento no está definido");
    }
  }

  static findByName(nombre) {
    const element = document.getElementById(nombre);
    return element ? new RegionPath(element) : null;
  }
}

class Response {
  constructor(objeto) {
    this.objet = objeto;
  }

  Region() {
    return this.objet.Region;
  }

  CasosPromedio() {
    return this.objet.CasosPromedio;
  }

  MuertesPromedio() {
    return this.objet.MuertesPromedio;
  }

  Fecha() {
    return this.objet.Fecha;
  }

  Mujeres(){
    return this.objet.Mujeres;
  }
  Hombres(){
    return this.objet.Hombres;
  }
}

const list = [
    {
        "Region":"CL-AI",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Abril 2020",
        "CasosPromedio":"1",
        "MuertesPromedio":"0",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"1",
        "MuertesPromedio":"0",
        "Mujeres":"40%",
        "Hombres":"60%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Junio 2020",
        "CasosPromedio":"5",
        "MuertesPromedio":"0",
        "Mujeres":"40%",
        "Hombres":"60%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Julio 2020",
        "CasosPromedio":"17",
        "MuertesPromedio":"0",
        "Mujeres":"40%",
        "Hombres":"60%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"96"
    
    },
    {
        "Region":"CL-AI",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"28",
        "MuertesPromedio":"0",
        "Mujeres":"40%",
        "Hombres":"60%",
        "Pap1":"41",
        "Pap2":"12",
        "Pap3":"",
        "Pap4":"96"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"55",
        "MuertesPromedio":"0",
        "Mujeres":"40%",
        "Hombres":"60%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"238",
        "MuertesPromedio":"0",
        "Mujeres":"50%",
        "Hombres":"50%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"379",
        "MuertesPromedio":"1",
        "Mujeres":"50%",
        "Hombres":"50%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"386",
        "MuertesPromedio":"2",
        "Mujeres":"50%",
        "Hombres":"50%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Enero 2021",
        "CasosPromedio":"673",
        "MuertesPromedio":"3",
        "Mujeres":"30%",
        "Hombres":"70%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"937",
        "MuertesPromedio":"4",
        "Mujeres":"40%",
        "Hombres":"60%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"1134",
        "MuertesPromedio":"5",
        "Mujeres":"50%",
        "Hombres":"50%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Abril 2021",
        "CasosPromedio":"1418",
        "MuertesPromedio":"6",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"1785",
        "MuertesPromedio":"6",
        "Mujeres":"50%",
        "Hombres":"50%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Junio 2021",
        "CasosPromedio":"2245",
        "MuertesPromedio":"10",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Julio 2021",
        "CasosPromedio":"2747",
        "MuertesPromedio":"13",
        "Mujeres":"70%",
        "Hombres":"30%",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"96"
    
    },
    {
        "Region":"CL-AI",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"2801",
        "MuertesPromedio":"15",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1":"41",
        "Pap2":"12",
        "Pap3":"0",
        "Pap4":"96"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"2612",
        "MuertesPromedio":"16",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"2905",
        "MuertesPromedio":"17",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"3237",
        "MuertesPromedio":"17",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AI",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"3443",
        "MuertesPromedio":"19",
        "Mujeres":"60%",
        "Hombres":"40%",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"1",
        "MuertesPromedio":"0",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Abril 2020",
        "CasosPromedio":"139",
        "MuertesPromedio":"0",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"265",
        "MuertesPromedio":"0",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Junio 2020",
        "CasosPromedio":"321",
        "MuertesPromedio":"3",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Julio 2020",
        "CasosPromedio":"468",
        "MuertesPromedio":"4",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"96"
    
    },
    {
        "Region":"CL-MA",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"739",
        "MuertesPromedio":"5",
        "Pap1":"41",
        "Pap2":"12",
        "Pap3":"",
        "Pap4":"96"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"3265",
        "MuertesPromedio":"9",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"3363",
        "MuertesPromedio":"18",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"4417",
        "MuertesPromedio":"27",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"35",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Enero 2021",
        "CasosPromedio":"6043",
        "MuertesPromedio":"40",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"6580",
        "MuertesPromedio":"47",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"7214",
        "MuertesPromedio":"56",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Abril 2021",
        "CasosPromedio":"8002",
        "MuertesPromedio":"61",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"8617",
        "MuertesPromedio":"65",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Junio 2021",
        "CasosPromedio":"8465",
        "MuertesPromedio":"74",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Julio 2021",
        "CasosPromedio":"9415",
        "MuertesPromedio":"81",
        "Pap1": "0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"96"
    
    },
    {
        "Region":"CL-MA",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"9468",
        "MuertesPromedio":"86",
        "Pap1":"41",
        "Pap2":"12",
        "Pap3":"",
        "Pap4":"96"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"8719",
        "MuertesPromedio":"89",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"9503",
        "MuertesPromedio":"92",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"9898",
        "MuertesPromedio":"95",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-MA",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"9711",
        "MuertesPromedio":"98",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Abril 2020",
        "CasosPromedio":"22",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"275",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Junio 2020",
        "CasosPromedio":"1143",
        "MuertesPromedio":"16",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Julio 2020",
        "CasosPromedio":"2204",
        "MuertesPromedio":"30",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"2297",
        "MuertesPromedio":"42",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"5736",
        "MuertesPromedio":"49",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"4000",
        "MuertesPromedio":"53",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"4574",
        "MuertesPromedio":"57",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"4337",
        "MuertesPromedio":"61",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Enero 2021",
        "CasosPromedio":"6463",
        "MuertesPromedio":"72",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"7859",
        "MuertesPromedio":"90",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"9259",
        "MuertesPromedio":"111",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Abril 2021",
        "CasosPromedio":"11382",
        "MuertesPromedio":"135",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"12533",
        "MuertesPromedio":"156",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Junio 2021",
        "CasosPromedio":"12387",
        "MuertesPromedio":"172",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Julio 2021",
        "CasosPromedio":"14092",
        "MuertesPromedio":"186",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"14474",
        "MuertesPromedio":"197",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"13484",
        "MuertesPromedio":"202",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"14956",
        "MuertesPromedio":"205",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"15957",
        "MuertesPromedio":"209",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-TA",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"15829",
        "MuertesPromedio":"213",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Abril 2020",
        "CasosPromedio":"66",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"399",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Junio 2020",
        "CasosPromedio":"1292",
        "MuertesPromedio":"18",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Julio 2020",
        "CasosPromedio":"3755",
        "MuertesPromedio":"49",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"5120",
        "MuertesPromedio":"75",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"5376",
        "MuertesPromedio":"88",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"6310",
        "MuertesPromedio":"95",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"6892",
        "MuertesPromedio":"105",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"6181",
        "MuertesPromedio":"110",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Enero 2021",
        "CasosPromedio":"8486",
        "MuertesPromedio":"116",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"10427",
        "MuertesPromedio":"136",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"12546",
        "MuertesPromedio":"161",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Abril 2021",
        "CasosPromedio":"14986",
        "MuertesPromedio":"183",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"16110",
        "MuertesPromedio":"200",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Junio 2021",
        "CasosPromedio":"16125",
        "MuertesPromedio":"217",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Julio 2021",
        "CasosPromedio":"18566",
        "MuertesPromedio":"233",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"19038",
        "MuertesPromedio":"247",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"17683",
        "MuertesPromedio":"257",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"19617",
        "MuertesPromedio":"264",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"20978",
        "MuertesPromedio":"272",
        
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AN",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"20908",
        "MuertesPromedio":"282",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Abril 2020",
        "CasosPromedio":"4",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"50",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Junio 2020",
        "CasosPromedio":"155",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Julio 2020",
        "CasosPromedio":"540",
        "MuertesPromedio":"1",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"1337",
        "MuertesPromedio":"5",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"1720",
        "MuertesPromedio":"10",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"2200",
        "MuertesPromedio":"14",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"2431",
        "MuertesPromedio":"18",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"2173",
        "MuertesPromedio":"20",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Enero 2021",
        "CasosPromedio":"2785",
        "MuertesPromedio":"21",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"3235",
        "MuertesPromedio":"26",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"3943",
        "MuertesPromedio":"32",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Abril 2021",
        "CasosPromedio":"5091",
        "MuertesPromedio":"39",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"5091",
        "MuertesPromedio":"44",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Junio 2021",
        "CasosPromedio":"6060",
        "MuertesPromedio":"53",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Julio 2021",
        "CasosPromedio":"6529",
        "MuertesPromedio":"63",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"7971",
        "MuertesPromedio":"74",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"8285",
        "MuertesPromedio":"78",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"8493",
        "MuertesPromedio":"81",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"9113",
        "MuertesPromedio":"84",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AT",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"9333",
        "MuertesPromedio":"89",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Abril 2020",
        "CasosPromedio":"21",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"69",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Junio 2020",
        "CasosPromedio":"479",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Julio 2020",
        "CasosPromedio":"1517",
        "MuertesPromedio":"6",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"2727",
        "MuertesPromedio":"12",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"1720",
        "MuertesPromedio":"22",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"4166",
        "MuertesPromedio":"28",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"4492",
        "MuertesPromedio":"33",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"4114",
        "MuertesPromedio":"35",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Enero 2021",
        "CasosPromedio":"5373",
        "MuertesPromedio":"39",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"6267",
        "MuertesPromedio":"46",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"8146",
        "MuertesPromedio":"61",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Abril 2021",
        "CasosPromedio":"10530",
        "MuertesPromedio":"80",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"12048",
        "MuertesPromedio":"93",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Junio 2021",
        "CasosPromedio":"13248",
        "MuertesPromedio":"109",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Julio 2021",
        "CasosPromedio":"16029",
        "MuertesPromedio":"127",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"16531",
        "MuertesPromedio":"138",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"15354",
        "MuertesPromedio":"146",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"16993",
        "MuertesPromedio":"151",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"18381",
        "MuertesPromedio":"158",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-CO",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"18660",
        "MuertesPromedio":"166",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"40",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Abril 2020",
        "CasosPromedio":"1517",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"9994",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Junio 2020",
        "CasosPromedio":"41152",
        "MuertesPromedio":"134",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Julio 2020",
        "CasosPromedio":"78084",
        "MuertesPromedio":"257",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"85815",
        "MuertesPromedio":"310",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"83500",
        "MuertesPromedio":"339",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"94738",
        "MuertesPromedio":"364",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"101231",
        "MuertesPromedio":"389",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"90292",
        "MuertesPromedio":"406",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Enero 2021",
        "CasosPromedio":"111721",
        "MuertesPromedio":"425",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"114266",
        "MuertesPromedio":"448",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"129314",
        "MuertesPromedio":"488",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Abril 2021",
        "CasosPromedio":"162303",
        "MuertesPromedio":"542",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"185529",
        "MuertesPromedio":"603",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Junio 2021",
        "CasosPromedio":"200071",
        "MuertesPromedio":"680",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Julio 2021",
        "CasosPromedio":"233639",
        "MuertesPromedio":"759",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"239070",
        "MuertesPromedio":"811",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"222454",
        "MuertesPromedio":"842",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"246889",
        "MuertesPromedio":"864",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"265692",
        "MuertesPromedio":"892",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-RM",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"262743",
        "MuertesPromedio":"920",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"2",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Abril 2020",
        "CasosPromedio":"102",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"428",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Junio 2020",
        "CasosPromedio":"2107",
        "MuertesPromedio":"8",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Julio 2020",
        "CasosPromedio":"5662",
        "MuertesPromedio":"21",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"8102",
        "MuertesPromedio":"32",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"9469",
        "MuertesPromedio":"42",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"11920",
        "MuertesPromedio":"52",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"13439",
        "MuertesPromedio":"60",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"12528",
        "MuertesPromedio":"65",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Enero 2021",
        "CasosPromedio":"16818",
        "MuertesPromedio":"71",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"18815",
        "MuertesPromedio":"81",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"23423",
        "MuertesPromedio":"99",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Abril 2021",
        "CasosPromedio":"32331",
        "MuertesPromedio":"124",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"37783",
        "MuertesPromedio":"144",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Junio 2021",
        "CasosPromedio":"40334",
        "MuertesPromedio":"166",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Julio 2021",
        "CasosPromedio":"48167",
        "MuertesPromedio":"189",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"49607",
        "MuertesPromedio":"205",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"46063",
        "MuertesPromedio":"214",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"50842",
        "MuertesPromedio":"221",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"54360",
        "MuertesPromedio":"228",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-VS",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"54860",
        "MuertesPromedio":"237",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"6",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Abril 2020",
        "CasosPromedio":"284",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"465",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Junio 2020",
        "CasosPromedio":"721",
        "MuertesPromedio":"3",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Julio 2020",
        "CasosPromedio":"1077",
        "MuertesPromedio":"4",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"1362",
        "MuertesPromedio":"5",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"1660",
        "MuertesPromedio":"6",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"2939",
        "MuertesPromedio":"7",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"4726",
        "MuertesPromedio":"11",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"5435",
        "MuertesPromedio":"15",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Enero 2021",
        "CasosPromedio":"8453",
        "MuertesPromedio":"21",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"10691",
        "MuertesPromedio":"27",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"14773",
        "MuertesPromedio":"39",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Abril 2021",
        "CasosPromedio":"21024",
        "MuertesPromedio":"54",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"25185",
        "MuertesPromedio":"66",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Junio 2021",
        "CasosPromedio":"26645",
        "MuertesPromedio":"81",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Julio 2021",
        "CasosPromedio":"30900",
        "MuertesPromedio":"94",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"31351",
        "MuertesPromedio":"106",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"29169",
        "MuertesPromedio":"112",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"31928",
        "MuertesPromedio":"117",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"33470",
        "MuertesPromedio":"121",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AR",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"33221",
        "MuertesPromedio":"126",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Abril 2020",
        "CasosPromedio":"17",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"106",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Junio 2020",
        "CasosPromedio":"742",
        "MuertesPromedio":"3",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Julio 2020",
        "CasosPromedio":"3065",
        "MuertesPromedio":"9",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"4620",
        "MuertesPromedio":"17",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"4936",
        "MuertesPromedio":"21",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"6382",
        "MuertesPromedio":"26",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"7226",
        "MuertesPromedio":"30",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"6648",
        "MuertesPromedio":"33",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Enero 2021",
        "CasosPromedio":"8746",
        "MuertesPromedio":"36",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"9871",
        "MuertesPromedio":"42",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"12122",
        "MuertesPromedio":"51",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Abril 2021",
        "CasosPromedio":"16059",
        "MuertesPromedio":"62",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"18698",
        "MuertesPromedio":"72",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Junio 2021",
        "CasosPromedio":"20248",
        "MuertesPromedio":"84",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Julio 2021",
        "CasosPromedio":"23630",
        "MuertesPromedio":"95",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"24055",
        "MuertesPromedio":"102",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"22312",
        "MuertesPromedio":"107",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"24577",
        "MuertesPromedio":"110",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"26091",
        "MuertesPromedio":"115",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LI",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"25744",
        "MuertesPromedio":"119",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"3",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Abril 2020",
        "CasosPromedio":"126",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"182",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Junio 2020",
        "CasosPromedio":"315",
        "MuertesPromedio":"1",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Julio 2020",
        "CasosPromedio":"816",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"1675",
        "MuertesPromedio":"4",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"2207",
        "MuertesPromedio":"5",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"3709",
        "MuertesPromedio":"7",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"5781",
        "MuertesPromedio":"11",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"6389",
        "MuertesPromedio":"15",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Enero 2021",
        "CasosPromedio":"10800",
        "MuertesPromedio":"20",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"15049",
        "MuertesPromedio":"33",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"18612",
        "MuertesPromedio":"51",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Abril 2021",
        "CasosPromedio":"22609",
        "MuertesPromedio":"64",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"24622",
        "MuertesPromedio":"70",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Junio 2021",
        "CasosPromedio":"25373",
        "MuertesPromedio":"82",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Julio 2021",
        "CasosPromedio":"29204",
        "MuertesPromedio":"92",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"29791",
        "MuertesPromedio":"99",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"27590",
        "MuertesPromedio":"102",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"302920",
        "MuertesPromedio":"107",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"32177",
        "MuertesPromedio":"112",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LL",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"32966",
        "MuertesPromedio":"118",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"1",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Abril 2020",
        "CasosPromedio":"66",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"192",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Junio 2020",
        "CasosPromedio":"876",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Julio 2020",
        "CasosPromedio":"2364",
        "MuertesPromedio":"7",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"3287",
        "MuertesPromedio":"14",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"3926",
        "MuertesPromedio":"18",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"5336",
        "MuertesPromedio":"23",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"6299",
        "MuertesPromedio":"29",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"6123",
        "MuertesPromedio":"33",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Enero 2021",
        "CasosPromedio":"9315",
        "MuertesPromedio":"39",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"11615",
        "MuertesPromedio":"49",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"14731",
        "MuertesPromedio":"62",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Abril 2021",
        "CasosPromedio":"20481",
        "MuertesPromedio":"77",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"24936",
        "MuertesPromedio":"91",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Junio 2021",
        "CasosPromedio":"26777",
        "MuertesPromedio":"105",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Julio 2021",
        "CasosPromedio":"31387",
        "MuertesPromedio":"117",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"32148",
        "MuertesPromedio":"127",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"29812",
        "MuertesPromedio":"132",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"32862",
        "MuertesPromedio":"136",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"35001",
        "MuertesPromedio":"141",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-ML",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"34816",
        "MuertesPromedio":"147",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Abril 2020",
        "CasosPromedio":"41",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"118",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Junio 2020",
        "CasosPromedio":"309",
        "MuertesPromedio":"5",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Julio 2020",
        "CasosPromedio":"929",
        "MuertesPromedio":"12",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"1791",
        "MuertesPromedio":"30",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"2110",
        "MuertesPromedio":"45",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"2756",
        "MuertesPromedio":"56",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"3159",
        "MuertesPromedio":"68",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"2851",
        "MuertesPromedio":"75",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Enero 2021",
        "CasosPromedio":"3671",
        "MuertesPromedio":"83",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"4183",
        "MuertesPromedio":"95",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"5049",
        "MuertesPromedio":"121",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Abril 2021",
        "CasosPromedio":"6286",
        "MuertesPromedio":"143",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"7060",
        "MuertesPromedio":"161",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Junio 2021",
        "CasosPromedio":"7265",
        "MuertesPromedio":"183",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Julio 2021",
        "CasosPromedio":"8530",
        "MuertesPromedio":"197",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"8723",
        "MuertesPromedio":"204",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"8114",
        "MuertesPromedio":"212",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"9067",
        "MuertesPromedio":"221",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"9597",
        "MuertesPromedio":"229",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-AP",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"9447",
        "MuertesPromedio":"235",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"0",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Abril 2020",
        "CasosPromedio":"76",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"107",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Junio 2020",
        "CasosPromedio":"172",
        "MuertesPromedio":"1",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Julio 2020",
        "CasosPromedio":"244",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"309",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"410",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"818",
        "MuertesPromedio":"3",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"1556",
        "MuertesPromedio":"6",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"2039",
        "MuertesPromedio":"10",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Enero 2021",
        "CasosPromedio":"3644",
        "MuertesPromedio":"17",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"5125",
        "MuertesPromedio":"27",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"7402",
        "MuertesPromedio":"45",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Abril 2021",
        "CasosPromedio":"10369",
        "MuertesPromedio":"61",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"11827",
        "MuertesPromedio":"67",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Junio 2021",
        "CasosPromedio":"12718",
        "MuertesPromedio":"85",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Julio 2021",
        "CasosPromedio":"15386",
        "MuertesPromedio":"104",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"15978",
        "MuertesPromedio":"119",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"14796",
        "MuertesPromedio":"127",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"16223",
        "MuertesPromedio":"133",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"17190",
        "MuertesPromedio":"138",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-LR",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"17270",
        "MuertesPromedio":"144",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"3",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Abril 2020",
        "CasosPromedio":"179",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"326",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Junio 2020",
        "CasosPromedio":"1057",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Julio 2020",
        "CasosPromedio":"2924",
        "MuertesPromedio":"5",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"4648",
        "MuertesPromedio":"10",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"6409",
        "MuertesPromedio":"16",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"9007",
        "MuertesPromedio":"23",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"11615",
        "MuertesPromedio":"33",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"12064",
        "MuertesPromedio":"42",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Enero 2021",
        "CasosPromedio":"18795",
        "MuertesPromedio":"55",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"22007",
        "MuertesPromedio":"71",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"28847",
        "MuertesPromedio":"92",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Abril 2021",
        "CasosPromedio":"38708",
        "MuertesPromedio":"117",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"43584",
        "MuertesPromedio":"130",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Junio 2021",
        "CasosPromedio":"45301",
        "MuertesPromedio":"148",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Julio 2021",
        "CasosPromedio":"52141",
        "MuertesPromedio":"164",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"53304",
        "MuertesPromedio":"178",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"49418",
        "MuertesPromedio":"187",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Octubre2021",
        "CasosPromedio":"54314",
        "MuertesPromedio":"194",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"57878",
        "MuertesPromedio":"201",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-BI",
        "Fecha": "Diciembre 2021",
        "CasosPromedio":"58582",
        "MuertesPromedio":"212",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Marzo 2020",
        "CasosPromedio":"4",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Abril 2020",
        "CasosPromedio":"220",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Mayo 2020",
        "CasosPromedio":"290",
        "MuertesPromedio":"0",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Junio 2020",
        "CasosPromedio":"530",
        "MuertesPromedio":"2",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Julio 2020",
        "CasosPromedio":"1094",
        "MuertesPromedio":"4",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Agosto 2020",
        "CasosPromedio":"1480",
        "MuertesPromedio":"6",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Septiembre 2020",
        "CasosPromedio":"1972",
        "MuertesPromedio":"8",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Octubre 2020",
        "CasosPromedio":"2659",
        "MuertesPromedio":"11",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Noviembre 2020",
        "CasosPromedio":"3241",
        "MuertesPromedio":"15",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Diciembre 2020",
        "CasosPromedio":"3327",
        "MuertesPromedio":"17",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Enero2021",
        "CasosPromedio":"4812",
        "MuertesPromedio":"21",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Febrero 2021",
        "CasosPromedio":"5780",
        "MuertesPromedio":"26",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Marzo 2021",
        "CasosPromedio":"7232",
        "MuertesPromedio":"37",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Abril 2021",
        "CasosPromedio":"9388",
        "MuertesPromedio":"45",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Mayo 2021",
        "CasosPromedio":"10655",
        "MuertesPromedio":"47",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Junio 2021",
        "CasosPromedio":"11179",
        "MuertesPromedio":"56",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Julio 2021",
        "CasosPromedio":"12980",
        "MuertesPromedio":"62",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Agosto 2021",
        "CasosPromedio":"13254",
        "MuertesPromedio":"66",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Septiembre 2021",
        "CasosPromedio":"12255",
        "MuertesPromedio":"69",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Octubre 2021",
        "CasosPromedio":"13509",
        "MuertesPromedio":"72",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Noviembre 2021",
        "CasosPromedio":"14366",
        "MuertesPromedio":"75",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    },
    {
        "Region":"CL-NU",
        "Fecha": "Diciembre2021",
        "CasosPromedio":"14416",
        "MuertesPromedio":"79",
        "Pap1":"0",
        "Pap2":"0",
        "Pap3":"0",
        "Pap4":"0"
    }
    ];

class RegionAPI {
  constructor(lista) {
    this.lista = lista;
  }

  getResponses() {
    return this.lista.map(item => new Response(item));
  }

  processRegions() {
    const pathCollection = RegionCollection.get();
    const fechaSeleccionada = document.getElementById('fecha').value;
    const casesElement = document.getElementById('contagios-dates');
    const deathsElement = document.getElementById('muertes-dates');

    let casosPromedioSum = 0;
    let muertesPromedioSum = 0;

    this.lista.forEach(item => {
      const regionPath = pathCollection.findByName(item.Region);
      if (regionPath) {
        const casosPromedio = parseInt(item.CasosPromedio);
        const muertesPromedio = parseInt(item.MuertesPromedio);
        let color = "green";

        if (casosPromedio === 0) {
          color = "#576EBD";
        } else if (casosPromedio >= 0 && casosPromedio <= 500) {
          color = "#576EBD";
        } else if (casosPromedio > 500 && casosPromedio <= 1000) {
          color = "#495DB6";
        } else if (casosPromedio > 1000 && casosPromedio <= 5000) {
          color = "#3750BF";
        } else if (casosPromedio > 5000 && casosPromedio <= 10000) {
          color = "#1A329E";
        } else if (casosPromedio > 10000 && casosPromedio <= 20000) {
          color = "#1B1B92";
        } else if (casosPromedio > 20000) {
          color = "#0A0A62";
        }

        if (item.Fecha === fechaSeleccionada) {
          regionPath.fill(color);
          casosPromedioSum += casosPromedio;
          muertesPromedioSum += muertesPromedio;
        }
      } else {
        console.log(`No se encontró el elemento para la región: ${item.Region}`);
      }
    });

    casesElement.innerText = casosPromedioSum.toString();
    casesElement.style.textAlign = 'center';
    deathsElement.innerText = muertesPromedioSum.toString();
    deathsElement.style.textAlign = 'center';
  }
}

const regionAPI = new RegionAPI(list);

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('fechaForm');
  const fechaSelector = document.getElementById('fecha');

  // Recuperar el valor seleccionado del almacenamiento web
  const selectedFecha = sessionStorage.getItem('selectedFecha');
  if (selectedFecha) {
    fechaSelector.value = selectedFecha;
  }

  // Procesar regiones al cargar la página
  regionAPI.processRegions();

  form.addEventListener('change', () => {
    // Guardar el valor seleccionado en el almacenamiento web
    const selectedValue = fechaSelector.value;
    sessionStorage.setItem('selectedFecha', selectedValue);

    regionAPI.processRegions();
  });
});