import re

archivo = open('paso_a_paso_std.csv', 'r', encoding='utf-8')

# Variables
Lista_main2 = []
Lista_aux111 = []
Diccionario = [['Tarapacá', '1'], ['Antofagasta', '2'], ['Atacama', '3'], ['Coquimbo', '4'], ['Valparaíso', '5'], ['O’Higgins', '6'], ['Maule', '7'], ['Biobío', '8'], ['Araucanía', '9'], ['Los Lagos', '10'], ['Aysén', '11'], ['Magallanes', '12'], ['Metropolitana', '13'], ['Los Ríos', '14'], ['Arica y Parinacota', '15'], ['Ñuble', '16']]

# Código de limpieza
for linea in archivo:
    uwu = linea.strip().split(',')
    Lista_aux111.append(uwu)

def paso_a_paso_2020(region, mes):
    codigo_region = ''
    paso1 = 0
    paso2 = 0
    paso3 = 0
    paso4 = 0
    paso5 = 0
    dato = ''  # Variable inicializada con valor predeterminado
    for codigo in Diccionario:
        if codigo[0] == region:
            codigo_region = codigo[1]
    for linea in Lista_aux111:
        slicing = linea[5]
        mes1 = slicing[5:7]
        year = slicing[0:4]

        if linea[0] == codigo_region and mes1 == mes and year == '2020':
            etapa = linea[6].rstrip('\n')
            if etapa == '1':
                paso1 += 1
            elif etapa == '2':
                paso2 += 1
            elif etapa == '3':
                paso3 += 1
            elif etapa == '4':
                paso4 += 1
            else:
                paso5 += 1
            dato = f'En el mes {mes} de 2020, hubieron {paso1} comunas en paso 1, {paso2} comunas en paso 2, {paso3} comunas en paso 3 y {paso4} comunas en paso 4.'

    return(dato)  # Se devuelve la variable con el valor correcto

# Ejemplo de uso
print(paso_a_paso_2020('Maule', '09'))