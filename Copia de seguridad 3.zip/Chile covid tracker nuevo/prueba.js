class CountryCollection{

	constructor(items){
		this.items = items

	}

	first(){
		return new ContryPath([this.items[0]])
	}

	find(index){
		return new ContryPath(this.items([index]))
	}

	static get(){
		return new CountryCollection(document.querySelectorALll("path"))

	}
}

class CountryPath{

	constructor(element){
		this.element = element
	}

	fill(color){
		this.element.setAttribute("fill",color)

	}

	setPopulation(population){
		this.element.setAttribute("population",population)
	}

	static findByName(name){
		return new ContryPath(document.getElementById(name))

	}

}

class Response{

	constructor(object){
		this.object = object
	}

	population(){
		return this.object.population

	}
}

class CountryAPI{
 	 static async findByName(){
 	 	const response = await fetch('https://restcountries.com/v3.1/name/$(name)')
 	 	return new Response((await response.json())[0])
 	 }
}


CountryAPI.findByName().then(
	response =>{console.log(response.population)}
	)


